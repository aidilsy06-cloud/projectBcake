<?php $__env->startSection('title', $store->name . ' — B’cake'); ?>

<?php $__env->startSection('content'); ?>

<?php
    // ========== HELPER KECIL UNTUK BANGUN URL GAMBAR ==========
    $makeImage = function ($raw, $default = null) {
        if (!$raw) {
            return $default;
        }

        $raw = ltrim($raw, '/');

        if (substr($raw, 0, 4) === 'http') {
            // sudah full URL (unsplash, dll)
            return $raw;
        }

        if (strpos($raw, 'storage/') === 0) {
            // sudah diawali storage/
            return asset($raw);
        }

        // contoh: "products/xxx.png" -> "/storage/products/xxx.png"
        return asset('storage/' . $raw);
    };

    // banner & logo
    $bannerSrc = $makeImage(
        $store->banner_url ?? $store->banner ?? null,
        'https://via.placeholder.com/1200x400?text=Banner+Toko'
    );

    $logoSrc = $makeImage(
        $store->logo_url ?? $store->logo ?? null,
        'https://via.placeholder.com/120.png?text=Logo'
    );
?>

<div class="mb-4 inline-flex">
    <a href="<?php echo e(route('buyer.stores.index')); ?>"
       class="px-3 py-1.5 rounded-full bg-rose-100 text-bcake-wine text-xs hover:bg-rose-200 transition">
        ← Kembali ke toko
    </a>
</div>


<section class="mb-8">
    <div class="relative h-56 rounded-2xl overflow-hidden shadow-soft">
        <img src="<?php echo e($bannerSrc); ?>"
             class="w-full h-full object-cover"
             alt="Banner <?php echo e($store->name); ?>">
    </div>

    <div class="flex items-center gap-4 mt-4">
        <img src="<?php echo e($logoSrc); ?>"
             class="h-20 w-20 rounded-xl object-cover border border-rose-200 shadow-soft"
             alt="Logo <?php echo e($store->name); ?>">

        <div>
            <h1 class="text-3xl font-display text-bcake-wine"><?php echo e($store->name); ?></h1>
            <p class="text-gray-600 text-sm">
                <?php echo e($store->description ?? 'Toko ini belum menambahkan deskripsi.'); ?>

            </p>

            <div class="mt-2 flex items-center gap-3 text-sm text-rose-600">
                <span>📍 <?php echo e($store->address ?? 'Alamat belum tersedia'); ?></span>
            </div>

            
            <?php
                $waNumber = null;

                if (!empty($store->whatsapp)) {
                    $rawWa = preg_replace('/\D+/', '', $store->whatsapp); // hanya angka

                    if (substr($rawWa, 0, 1) === '0') {
                        $rawWa = '62' . substr($rawWa, 1); // 08xxxx -> 62xxxx
                    }

                    $waNumber = $rawWa;
                }
            ?>

            <div class="mt-3">
                <?php if($waNumber): ?>
                    <a href="https://wa.me/<?php echo e($waNumber); ?>"
                       target="_blank"
                       class="inline-flex items-center gap-2 px-4 py-1.5 text-sm bg-emerald-600 text-white rounded-full hover:bg-emerald-700">
                        <span>Chat Penjual</span>
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                  d="M9 12h6m-3-3v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </a>
                <?php else: ?>
                    <p class="text-xs text-rose-500">
                        Toko belum mengatur nomor WhatsApp.
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>




<section class="bg-white border border-rose-200/40 rounded-2xl p-6 mb-12 shadow-soft">
    <h2 class="text-xl font-semibold text-bcake-bitter mb-3">Pesan Langsung dari Toko</h2>
    <p class="text-gray-600 text-sm mb-4">
        Isi data berikut untuk melakukan pemesanan. Setelah submit, kamu akan diarahkan ke WhatsApp penjual 💗
    </p>

    <form action="<?php echo e(route('stores.order', $store)); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>

        
        <div>
            <label class="block text-sm font-medium mb-1">Nama Lengkap</label>
            <input type="text" name="customer_name"
                   value="<?php echo e(old('customer_name', auth()->user()->name ?? '')); ?>"
                   required
                   class="w-full rounded-xl border border-rose-200 px-4 py-2 focus:ring-rose-300 focus:border-rose-300">
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Nomor WhatsApp</label>
            <input type="text" name="customer_phone"
                   value="<?php echo e(old('customer_phone')); ?>"
                   placeholder="08xxxx"
                   required
                   class="w-full rounded-xl border border-rose-200 px-4 py-2 focus:ring-rose-300 focus:border-rose-300">
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Alamat (Opsional)</label>
            <textarea name="customer_address" rows="2"
                      class="w-full rounded-xl border border-rose-200 px-4 py-2 focus:ring-rose-300 focus:border-rose-300"
                      placeholder="Tulis alamat lengkap jika perlu pengantaran"><?php echo e(old('customer_address')); ?></textarea>
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Ringkasan Pesanan</label>
            <textarea name="order_summary" rows="2"
                      required
                      class="w-full rounded-xl border border-rose-200 px-4 py-2 focus:ring-rose-300 focus:border-rose-300"
                      placeholder="Contoh: 1x Red Velvet ukuran M, 2x Cupcake Cokelat"><?php echo e(old('order_summary')); ?></textarea>
        </div>

        
        <div>
            <label class="block text-sm font-medium mb-1">Catatan Tambahan (Opsional)</label>
            <textarea name="note" rows="2"
                      class="w-full rounded-xl border border-rose-200 px-4 py-2 focus:ring-rose-300 focus:border-rose-300"
                      placeholder="Contoh: tanpa kacang, diambil jam 3 sore, dll"><?php echo e(old('note')); ?></textarea>
        </div>

        <button type="submit"
                class="px-5 py-2.5 rounded-full bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-2">
            <span>Kirim ke WhatsApp Penjual</span>
            <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M5 12h14m-7-7l7 7-7 7"/>
            </svg>
        </button>
    </form>
</section>




<section>
    <h2 class="text-xl font-semibold text-bcake-bitter mb-4">Produk dari <?php echo e($store->name); ?></h2>

    <?php if($products->count() == 0): ?>
        <p class="text-gray-500 text-sm">Toko ini belum menambahkan produk.</p>
    <?php else: ?>
        <div class="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $productImg = $makeImage(
                        $product->image_url
                            ?? $product->cover_url
                            ?? $product->photo
                            ?? $product->image
                            ?? null,
                        'https://via.placeholder.com/400'
                    );
                ?>

                <a href="<?php echo e(route('products.show', $product->slug)); ?>"
                   class="block bg-white rounded-2xl border border-rose-200 overflow-hidden shadow-soft hover:shadow-lg transition">
                    <img src="<?php echo e($productImg); ?>"
                         class="w-full h-52 object-cover"
                         alt="<?php echo e($product->name); ?>">

                    <div class="p-4">
                        <h3 class="font-medium text-bcake-bitter"><?php echo e($product->name); ?></h3>
                        <p class="text-sm text-gray-500 mt-1">
                            Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                        </p>

                        <span class="text-xs text-white bg-bcake-wine px-2 py-1 rounded-full mt-2 inline-block">
                            <?php echo e($product->category->name ?? 'Kategori'); ?>

                        </span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projectBcake\resources\views/stores/show.blade.php ENDPATH**/ ?>