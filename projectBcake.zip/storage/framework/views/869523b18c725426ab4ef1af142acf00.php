

<?php $__env->startSection('title', 'Daftar Toko — B’cake'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-rose-50 py-10">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

        
        <div class="text-center mb-4">
            <h1 class="text-2xl md:text-3xl font-semibold text-rose-900">
                Jelajahi Toko Favorit di B’cake
            </h1>
            <p class="text-sm text-rose-500 mt-1">
                Pilih toko untuk melihat katalog kue, custom cake, dan dessert mereka.
            </p>
        </div>

        
        <?php if($stores->isEmpty()): ?>
            <div class="bg-white rounded-3xl shadow-sm px-6 py-10 text-center">
                <p class="text-rose-700 font-medium mb-1">Belum ada toko yang terdaftar.</p>
                <p class="text-sm text-rose-500">
                    Toko-toko B’cake akan muncul di sini setelah penjual mendaftarkan tokonya.
                </p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-2xl shadow-sm border border-rose-100/70 overflow-hidden flex flex-col">
                        
                        <div class="h-20 bg-gradient-to-r from-rose-100 via-rose-50 to-amber-50"></div>

                        <div class="px-5 pb-4 pt-3 flex-1 flex flex-col">
                            <h2 class="text-base font-semibold text-rose-900">
                                <?php echo e($store->name); ?>

                            </h2>

                            <?php if($store->tagline): ?>
                                <p class="text-xs text-rose-400 mt-1">
                                    <?php echo e($store->tagline); ?>

                                </p>
                            <?php endif; ?>

                            <?php if($store->description): ?>
                                <p class="text-xs text-rose-500 mt-2 line-clamp-3">
                                    <?php echo e($store->description); ?>

                                </p>
                            <?php endif; ?>

                            <div class="mt-4 flex items-center justify-between">
                                <?php if($store->whatsapp): ?>
                                    <span class="text-[11px] text-rose-400">
                                        WA: <?php echo e($store->whatsapp); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-[11px] text-rose-300">
                                        WhatsApp belum diatur
                                    </span>
                                <?php endif; ?>

                                <a href="<?php echo e(route('stores.show', $store->slug)); ?>"
                                   class="inline-flex items-center px-3 py-1 rounded-full
                                          bg-rose-500 text-white text-xs font-semibold
                                          hover:bg-rose-600">
                                    Lihat Toko →
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <div class="mt-6">
                <?php echo e($stores->links()); ?>

            </div>
        <?php endif; ?>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\projectBcake\resources\views/stores/index.blade.php ENDPATH**/ ?>